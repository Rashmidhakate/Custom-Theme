<?php
namespace Magehit\Bestsellerproducts\Model\ResourceModel\Report\Bestsellers;

class Collection extends \Magento\Sales\Model\ResourceModel\Report\Bestsellers\Collection
{
    protected $_ratingLimit = 10;   
}