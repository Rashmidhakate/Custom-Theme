var config = {
    map: {
        '*': {
            cpowlcarousel: 'Magehit_Bestsellerproducts/js/slick'
        }
    }
};
