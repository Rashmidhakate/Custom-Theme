var config = {
    paths: {            
            'bxslider': "Magento_CatalogWidget/js/slick"
        },   
    shim: {
        'bxslider': {
            deps: ['jquery']
        }
    }
};