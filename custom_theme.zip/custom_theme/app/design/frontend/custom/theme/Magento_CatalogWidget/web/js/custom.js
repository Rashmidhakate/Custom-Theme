require([
  'jquery',
  'jquery/ui'
], function($){
	$(window).load(function() {
		
		//fotorama button setting
		$(".fotorama__thumb__arr--left").insertBefore(".fotorama__nav");
		$(".fotorama__thumb__arr--right").insertAfter(".fotorama__nav");
		
	});
 
	$(document).ready(function () {
	//code for my-account toggle
		$( ".header-account-button" ).click(function() {
			$( ".dropdown-menu-account" ).toggle();
		});	
	//code for cabinet style subcat page
		$('.subcatdiv:eq(0)').addClass('active');		
		$('ul.cabinet-pro li:first-child()').addClass('active');
		$("ul.cabinet-pro a").click(function(){
			var subcatdiv = $(this).attr("rel");
			$("div.subcatdiv").siblings().removeClass('active');
			$("div."+subcatdiv).addClass('active');		
			
			$(this).parent().addClass('active');
			$(this).parent().siblings().removeClass('active');	
		});
	//code for cabinet style for mobile subcat page
		$('.tab-accordion .tab:first-child()').addClass('active');
		$(".tab-accordion .tab a").on('click', function(){
			$(this).parent().toggleClass('active');
			$(this).parent().next().slideToggle('slow');
			$(this).parent().next().toggleClass('active');
		});
	//footer accordion for mobile version
	 //$(".footer-block h2").on('click', function(){
		//$(this).parent().toggleClass('checked').siblings().removeClass('checked');
	 //})	
	$(".footer-block h2").on('click', function(){
		$(this).parent().toggleClass('checked');
		$(this).next().slideToggle();
	 })
	 

	 //sticky menu footer
	 $(window).scroll(function() {    
     var scroll = $(window).scrollTop();
		if (scroll > 500) {
			$(".mobnav-fixed").addClass("sticky");
		} else {
            $(".mobnav-fixed").removeClass("sticky");
        }
	});
	
	//filter toggle Also added in  app\code\Mageplaza\LayeredNavigation\view\frontend\web\js\action\submit-filter.js
	 $('.filter-layered.mobile a').click(function(){
        $('.filter-options').slideToggle("slow");
    });
	

 $(window).load(function() {
		// Animate loader off screen
		$(".homeloader").fadeOut("slow");;
	});

		
	//code for show more/less
	if($("div.category-description.show").length)
	{
		$(function() {
		var showTotalChar = 400, showChar = "Show More", hideChar = "Show Less";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots"></span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		$(this).html(txt);
		}
		});
		$(".showmoretxt").click(function() {
		if ($(this).hasClass("sample")) {
		$(this).removeClass("sample");
		$(this).text(showChar);
		} else {
		$(this).addClass("sample");
		$(this).text(hideChar);
		}
		$(this).parent().prev().toggle();
		$(this).prev().toggle();
		return false;
		});	
		});
	}
	
	$(".form-shipping-address .control select").parent().addClass("selectbox"); 
	
	// Home page help css
		$(document).ready(function(){
   			$("#hide").click(function(){
        		//$(".need-help-part").hide();
        		$(".header-helpsection").removeClass("btn-hide");
    		});
		    $("#show").click(function(){
		        //$(".need-help-part").show();
		        $(".header-helpsection").addClass("btn-hide");
		    });

		    $(".accessories-content-part .readmore").click(function(){
		    	$(".accessories-content-part .acc-decs-part").hide();
		    	$(".accessories-content-part #description_full").show();
		    });

		    $(".accessories-content-part .less").click(function(){
		    	$(".accessories-content-part .acc-decs-part").show();
		    	$(".accessories-content-part #description_full").hide();
		    });


		    $(".event-detail-wrape .readmore").click(function(){
		    	$(".event-detail-wrape .eventdetail").hide();
		    	$(".event-detail-wrape #description_full").show();
		    });

		    $(".event-detail-wrape .less").click(function(){
		    	$(".event-detail-wrape .eventdetail").show();
		    	$(".event-detail-wrape #description_full").hide();
		    });
		});
	
	// faq module css
		/* $('.product-infotab #description1').hide();
		$('.product-infotab #heading1:first').addClass('active').next().slideDown('slow');
		$('.product-infotab #heading1').click(function() {
			if($(this).next().is(':hidden')) {
				$('.product-infotab #heading1').removeClass('active').next().slideUp('slow');
				$(this).toggleClass('active').next().slideDown('slow');
		   }else{
				$('.product-infotab #heading1').removeClass('active').next().slideUp('slow'); 
		   }
		}); */
		
		$('.product-infotab#description #heading1').addClass('active').next().slideDown('slow');
		$('.product-infotab#description #heading1').click(function() {
			if($(this).next().is(':visible')) {
				$('.product-infotab#description #heading1').removeClass('active').next().slideUp('slow');
		   }else{
				$('.product-infotab#description #heading1').addClass('active').next().slideDown('slow'); 
		   }
		  });
		
		$('.product-infotab#readytoship .heading').addClass('active').next().slideDown('slow');
		$('.product-infotab#readytoship .heading').click(function() {
			 if($(this).next().is(':visible')) {
				$('.product-infotab#readytoship .heading').removeClass('active').next().slideUp('slow');
		   }else{
				$('.product-infotab#readytoship .heading').addClass('active').next().slideDown('slow'); 
		  }
		  });
		  
		$('.product-infotab#madeonorder .heading').addClass('active').next().slideDown('slow');
		$('.product-infotab#madeonorder .heading').click(function() {
			 if($(this).next().is(':visible')) {
				$('.product-infotab#madeonorder .heading').removeClass('active').next().slideUp('slow');
		   }else{
				$('.product-infotab#madeonorder .heading').addClass('active').next().slideDown('slow'); 
		  }
		  });
		
		// Back to Top
		$(function () { $(window).scroll(function () { if ($(this).scrollTop() > 100) { $('#back-top').fadeIn(); } else { $('#back-top').fadeOut(); } }); // scroll body to 0px on click 
		$('#back-top').click(function () { $('body,html').animate({ scrollTop: 0 }, 800); return false; }); });
		
	//popup tabbing
	$('ul.tabs li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabs li').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	})
		
				
	 
	});
});
